package cu.cs.cpsc215.project1;

public class WebImage {

	private String m_name;
	
	public WebImage(String name){
		m_name = name;
	}
	
	public String toString(){
		return(m_name);
	}
}
