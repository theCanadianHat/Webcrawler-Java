package cu.cs.cpsc215.project1;

public class WebFile {

	private String m_name;
	
	public WebFile(String name){
		m_name = name;
	}

	public String toString(){
		return(m_name);
	}
}
