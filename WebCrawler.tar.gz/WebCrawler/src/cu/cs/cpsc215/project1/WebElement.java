package cu.cs.cpsc215.project1;

import java.util.Vector;

public interface WebElement {



	public void crawl(int depth, String string);

	
}
